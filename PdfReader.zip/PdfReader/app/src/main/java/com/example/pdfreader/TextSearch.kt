package com.example.pdfreader

import android.content.Context
import android.net.Uri
import android.graphics.RectF
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.text.Normalizer
import kotlin.math.abs

/**
 * نص صفحة واحدة بعد التطبيع.
 * rects: لكل حرف أربع قيم (يسار، أعلى، يمين، أسفل) بنسبة 0..1 من حجم الصفحة، أو NaN إن لم يكن له موضع.
 */
class PageText(val text: String, val rects: FloatArray)

/** نتيجة بحث: رقم الصفحة ومستطيلات التظليل (مستطيل لكل سطر). */
class Hit(val page: Int, val rects: List<RectF>)

object TextNorm {
    /** يعيد الحرف بعد التطبيع، أو null إن كان يجب تجاهله (تشكيل، تطويل، رموز اتجاه). */
    fun normChar(c: Char): Char? {
        if (c.isWhitespace() || c == ' ') return ' '
        val code = c.code
        if (code == 0x0640 ||                 // تطويل
            code in 0x064B..0x065F ||          // حركات التشكيل
            code == 0x0670 ||
            code in 0x200B..0x200F ||          // رموز اتجاه/عرض صفري
            code in 0x202A..0x202E ||
            code == 0xFEFF
        ) return null
        return when (c) {
            'أ', 'إ', 'آ', 'ٱ' -> 'ا'  // أ إ آ ٱ -> ا
            'ى', 'ی' -> 'ي'                      // ى ی -> ي
            'ک' -> 'ك'                                // ک -> ك
            else -> c.lowercaseChar()
        }
    }

    fun normalizeQuery(q: String): String {
        val sb = StringBuilder()
        for (c in q) {
            val n = normChar(c) ?: continue
            if (n == ' ' && (sb.isEmpty() || sb.last() == ' ')) continue
            sb.append(n)
        }
        return sb.toString().trim()
    }
}

/** يستخرج نص كل الصفحات مع مواضع الحروف (مرة واحدة لكل ملف). */
object TextIndexer {
    private var initialized = false

    private class FloatBuf {
        var a = FloatArray(4096)
        var n = 0
        fun add(v: Float) {
            if (n == a.size) a = a.copyOf(n * 2)
            a[n++] = v
        }
        fun clear() { n = 0 }
        fun toArray(): FloatArray = a.copyOf(n)
    }

    private class Collector(
        private val total: Int,
        private val onProgress: (Int, Int) -> Unit
    ) : PDFTextStripper() {
        val pages = ArrayList<PageText>()
        private val sb = StringBuilder()
        private val rects = FloatBuf()

        private fun appendChar(ch: Char, l: Float, t: Float, r: Float, b: Float) {
            sb.append(ch)
            rects.add(l); rects.add(t); rects.add(r); rects.add(b)
        }

        override fun startPage(page: PDPage) {
            sb.setLength(0)
            rects.clear()
            super.startPage(page)
        }

        override fun endPage(page: PDPage) {
            pages.add(PageText(sb.toString(), rects.toArray()))
            if (pages.size % 5 == 0 || pages.size == total) onProgress(pages.size, total)
            super.endPage(page)
        }

        override fun writeString(text: String, textPositions: MutableList<TextPosition>) {
            if (sb.isNotEmpty() && sb.last() != ' ') {
                appendChar(' ', Float.NaN, Float.NaN, Float.NaN, Float.NaN)
            }
            for (tp in textPositions) {
                val raw = tp.unicode ?: continue
                val pw = tp.pageWidth
                val ph = tp.pageHeight
                if (pw <= 0f || ph <= 0f) continue
                val l = tp.xDirAdj / pw
                val r = (tp.xDirAdj + tp.widthDirAdj) / pw
                val b = tp.yDirAdj / ph
                val t = (tp.yDirAdj - tp.heightDir) / ph
                // NFKC يحوّل أشكال الحروف العربية المتصلة (FExx) وروابط مثل ﬁ إلى حروف عادية
                val u = Normalizer.normalize(raw, Normalizer.Form.NFKC)
                for (c in u) {
                    val n = TextNorm.normChar(c) ?: continue
                    if (n == ' ' && sb.isNotEmpty() && sb.last() == ' ') continue
                    appendChar(n, l, t, r, b)
                }
            }
        }
    }

    fun build(context: Context, uri: Uri, onProgress: (Int, Int) -> Unit): List<PageText> {
        synchronized(this) {
            if (!initialized) {
                PDFBoxResourceLoader.init(context.applicationContext)
                initialized = true
            }
        }
        val input = context.contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("cannot open")
        input.use {
            val pd = PDDocument.load(it)
            try {
                val stripper = Collector(pd.numberOfPages, onProgress)
                stripper.getText(pd)
                return stripper.pages
            } finally {
                pd.close()
            }
        }
    }
}

object Searcher {
    private const val MAX_HITS = 5000

    private fun hasRtl(s: String) = s.any { it.code in 0x0590..0x08FF }

    private fun collect(text: String, q: String, out: MutableList<IntArray>) {
        var from = 0
        while (true) {
            val i = text.indexOf(q, from)
            if (i < 0) break
            out.add(intArrayOf(i, i + q.length))
            from = i + q.length
        }
    }

    fun search(index: List<PageText>, rawQuery: String): List<Hit> {
        val q = TextNorm.normalizeQuery(rawQuery)
        if (q.isEmpty()) return emptyList()
        // بعض ملفات PDF العربية تخزّن الحروف بترتيب بصري معكوس، فنبحث بالاتجاهين
        val reversed = q.reversed().takeIf { it != q && hasRtl(q) }
        val out = ArrayList<Hit>()
        for ((page, pt) in index.withIndex()) {
            val ranges = ArrayList<IntArray>()
            collect(pt.text, q, ranges)
            if (reversed != null) collect(pt.text, reversed, ranges)
            ranges.sortBy { it[0] }
            var lastEnd = -1
            for (r in ranges) {
                if (r[0] < lastEnd) continue
                lastEnd = r[1]
                val rects = rectsFor(pt, r[0], r[1])
                if (rects.isNotEmpty()) out.add(Hit(page, rects))
                if (out.size >= MAX_HITS) return out
            }
        }
        return out
    }

    private fun rectsFor(pt: PageText, start: Int, end: Int): List<RectF> {
        val res = ArrayList<RectF>()
        var cur: RectF? = null
        for (i in start until end) {
            val o = i * 4
            if (o + 3 >= pt.rects.size) break
            val l = pt.rects[o]
            if (l.isNaN()) continue
            val t = pt.rects[o + 1]
            val r = pt.rects[o + 2]
            val b = pt.rects[o + 3]
            val c = cur
            if (c == null) {
                cur = RectF(l, t, r, b)
            } else {
                val cy = (t + b) / 2f
                val cyCur = (c.top + c.bottom) / 2f
                if (abs(cy - cyCur) < 0.6f * (c.bottom - c.top).coerceAtLeast(0.005f)) {
                    c.union(l, t, r, b)
                } else {
                    res.add(c)
                    cur = RectF(l, t, r, b)
                }
            }
        }
        cur?.let { res.add(it) }
        return res
    }
}
