package com.example.pdfreader

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.LruCache
import kotlin.math.sqrt

/** صفحة مرسومة مع العرض الذي طُلب رسمها به. */
class Rendered(val bitmap: Bitmap, val requestedWidth: Int)

/** يمثّل ملف PDF مفتوحًا (تبويب واحد). */
class PdfDoc(
    val uri: Uri,
    val name: String,
    private val pfd: ParcelFileDescriptor,
    private val renderer: PdfRenderer
) {
    private val lock = Any()
    private var closed = false

    val pageCount: Int = renderer.pageCount

    /** نسبة الارتفاع إلى العرض للصفحة الأولى، تُستخدم لحجز مساحة الصفحات قبل رسمها. */
    val aspect: Float

    // موضع التمرير المحفوظ عند التنقل بين التبويبات
    var scrollPosition = 0
    var scrollOffset = 0

    // ---- حالة البحث ----
    @Volatile var textIndex: List<PageText>? = null
    @Volatile var indexing = false
    var indexFailed = false
    var query = ""
    var hits: List<Hit> = emptyList()
        private set
    var hitIndex = -1
    var hitsByPage: Map<Int, List<Pair<Int, List<RectF>>>> = emptyMap()
        private set

    fun setHits(newHits: List<Hit>) {
        hits = newHits
        val map = HashMap<Int, MutableList<Pair<Int, List<RectF>>>>()
        newHits.forEachIndexed { i, hit ->
            map.getOrPut(hit.page) { ArrayList() }.add(i to hit.rects)
        }
        hitsByPage = map
    }

    private val cache = object : LruCache<Int, Rendered>(
        (Runtime.getRuntime().maxMemory() / 1024 / 4).toInt()
    ) {
        override fun sizeOf(key: Int, value: Rendered) = value.bitmap.byteCount / 1024
    }

    init {
        aspect = if (pageCount > 0) {
            val p = renderer.openPage(0)
            val a = p.height.toFloat() / p.width
            p.close()
            a
        } else 1.414f
    }

    fun cached(index: Int): Rendered? = cache.get(index)

    /** رسم صفحة بعرض معيّن (يُستدعى من خيط خلفي). */
    fun render(index: Int, width: Int): Rendered? = synchronized(lock) {
        cache.get(index)?.let { if (it.requestedWidth >= width) return it }
        if (closed || index !in 0 until pageCount) return null
        val page = renderer.openPage(index)
        try {
            var w = width.coerceAtLeast(1)
            var h = (w.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
            // حدّ أقصى لحجم الصورة حتى لا تنفد الذاكرة عند التكبير الكبير
            val maxPixels = 12_000_000.0
            if (w.toDouble() * h > maxPixels) {
                val f = sqrt(maxPixels / (w.toDouble() * h))
                w = (w * f).toInt().coerceAtLeast(1)
                h = (h * f).toInt().coerceAtLeast(1)
            }
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            val result = Rendered(bmp, width)
            cache.put(index, result)
            result
        } finally {
            page.close()
        }
    }

    fun close() {
        synchronized(lock) {
            if (closed) return
            closed = true
            cache.evictAll()
            try { renderer.close() } catch (e: Exception) {}
            try { pfd.close() } catch (e: Exception) {}
        }
    }
}
