package com.example.pdfreader

import android.content.Intent
import android.graphics.Rect
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.KeyEvent
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.tabs.TabLayout
import java.util.concurrent.Executors
import kotlin.math.ceil

class MainActivity : AppCompatActivity() {

    private val docs = mutableListOf<PdfDoc>()
    private val renderExecutor = Executors.newFixedThreadPool(2)
    private val indexExecutor = Executors.newSingleThreadExecutor()

    private lateinit var tabs: TabLayout
    private lateinit var recycler: ZoomRecyclerView
    private lateinit var emptyView: View
    private lateinit var indicator: TextView
    private lateinit var layoutManager: LinearLayoutManager

    private lateinit var searchBar: View
    private lateinit var searchInput: EditText
    private lateinit var searchCount: TextView

    private var adapter: PageAdapter? = null
    private var current = -1
    private var updatingTabs = false

    private val currentDoc: PdfDoc? get() = docs.getOrNull(current)

    private val picker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> handleUris(uris) }

    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = closeSearch()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        onBackPressedDispatcher.addCallback(this, backCallback)

        setSupportActionBar(findViewById<MaterialToolbar>(R.id.toolbar))
        tabs = findViewById(R.id.tabs)
        recycler = findViewById(R.id.pages)
        emptyView = findViewById(R.id.empty)
        indicator = findViewById(R.id.indicator)
        searchBar = findViewById(R.id.search_bar)
        searchInput = findViewById(R.id.search_input)
        searchCount = findViewById(R.id.search_count)
        findViewById<Button>(R.id.btn_open).setOnClickListener { openPicker() }

        layoutManager = LinearLayoutManager(this)
        recycler.layoutManager = layoutManager
        val gap = (8 * resources.displayMetrics.density).toInt()
        recycler.addItemDecoration(object : RecyclerView.ItemDecoration() {
            override fun getItemOffsets(out: Rect, v: View, p: RecyclerView, s: RecyclerView.State) {
                out.set(0, gap, 0, 0)
            }
        })
        recycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) = updateIndicator()
        })
        recycler.onZoomSettled = { s -> applyZoom(s) }

        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                if (!updatingTabs) showDoc(tab.position)
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {
                if (!updatingTabs) saveScroll()
            }
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        // ---- شريط البحث ----
        searchInput.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER &&
                    event.action == KeyEvent.ACTION_DOWN)
            ) {
                submitSearch()
                true
            } else false
        }
        findViewById<ImageButton>(R.id.btn_next).setOnClickListener { stepHit(1) }
        findViewById<ImageButton>(R.id.btn_prev).setOnClickListener { stepHit(-1) }
        findViewById<ImageButton>(R.id.btn_search_close).setOnClickListener { closeSearch() }

        showDoc(-1)
        restoreSession()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW && intent.data != null) {
            handleUris(listOf(intent.data!!))
        }
    }

    // ---------------------------------------------------------------- القائمة

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val has = current >= 0
        menu.findItem(R.id.action_close).isVisible = has
        menu.findItem(R.id.action_search).isVisible = has
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_open -> { openPicker(); true }
        R.id.action_close -> { if (current >= 0) confirmClose(current); true }
        R.id.action_search -> {
            if (searchBar.visibility == View.VISIBLE) closeSearch() else openSearch()
            true
        }
        else -> super.onOptionsItemSelected(item)
    }

    // ---------------------------------------------------------------- فتح الملفات والتبويبات

    private fun openPicker() = picker.launch(arrayOf("application/pdf"))

    private fun handleUris(uris: List<Uri>) {
        var last = -1
        for (uri in uris) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {}
            val idx = openUri(uri)
            if (idx >= 0) last = idx
        }
        if (last >= 0) selectTab(last)
    }

    /** يفتح الملف في تبويب جديد (أو يعيد تبويبه إن كان مفتوحًا) ويعيد رقم التبويب. */
    private fun openUri(uri: Uri): Int {
        val existing = docs.indexOfFirst { it.uri == uri }
        if (existing >= 0) return existing
        return try {
            val pfd = contentResolver.openFileDescriptor(uri, "r") ?: throw IllegalStateException()
            val doc = try {
                PdfDoc(uri, queryName(uri), pfd, PdfRenderer(pfd))
            } catch (e: Exception) {
                pfd.close(); throw e
            }
            updatingTabs = true
            docs.add(doc)
            tabs.addTab(tabs.newTab().setText(doc.name), false)
            val index = docs.size - 1
            tabs.getTabAt(index)?.view?.setOnLongClickListener { confirmClose(docs.indexOf(doc)); true }
            updatingTabs = false
            index
        } catch (e: Exception) {
            updatingTabs = false
            Toast.makeText(this, R.string.open_error, Toast.LENGTH_LONG).show()
            -1
        }
    }

    private fun selectTab(index: Int) {
        if (current >= 0 && current != index) saveScroll()
        tabs.getTabAt(index)?.select()
        if (current != index) showDoc(index)
    }

    private fun baseWidth(): Int =
        recycler.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels

    private fun showDoc(index: Int) {
        current = index
        invalidateOptionsMenu()
        adapter?.dispose()
        adapter = null
        recycler.resetZoom()

        if (index < 0 || index >= docs.size) {
            current = -1
            recycler.adapter = null
            recycler.visibility = View.GONE
            indicator.visibility = View.GONE
            emptyView.visibility = View.VISIBLE
            if (searchBar.visibility == View.VISIBLE) hideSearchBar()
            return
        }
        val doc = docs[index]
        emptyView.visibility = View.GONE
        recycler.visibility = View.VISIBLE
        val a = PageAdapter(doc, baseWidth(), renderExecutor)
        adapter = a
        recycler.adapter = a
        layoutManager.scrollToPositionWithOffset(doc.scrollPosition, doc.scrollOffset)
        recycler.post { updateIndicator() }

        if (searchBar.visibility == View.VISIBLE) {
            searchInput.setText(doc.query)
            updateCount(doc)
        }
    }

    private fun saveScroll() {
        val doc = currentDoc ?: return
        val pos = layoutManager.findFirstVisibleItemPosition()
        if (pos >= 0) {
            doc.scrollPosition = pos
            doc.scrollOffset = layoutManager.findViewByPosition(pos)?.top ?: 0
        }
    }

    private fun updateIndicator() {
        val doc = currentDoc ?: return
        val pos = layoutManager.findFirstVisibleItemPosition()
        if (pos < 0) return
        indicator.text = "${pos + 1} / ${doc.pageCount}"
        indicator.visibility = View.VISIBLE
    }

    private fun confirmClose(index: Int) {
        if (index !in docs.indices) return
        AlertDialog.Builder(this)
            .setMessage(getString(R.string.close_confirm, docs[index].name))
            .setPositiveButton(R.string.yes) { _, _ -> closeTab(index) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun closeTab(index: Int) {
        if (index !in docs.indices) return
        updatingTabs = true
        val wasCurrent = index == current
        val doc = docs.removeAt(index)
        tabs.removeTabAt(index)
        if (wasCurrent) {
            adapter?.dispose()
            adapter = null
            recycler.adapter = null
        }
        doc.close()
        // إعادة ربط ضغطة الإطالة بأرقام التبويبات الجديدة
        for (d in docs) {
            tabs.getTabAt(docs.indexOf(d))?.view?.setOnLongClickListener { confirmClose(docs.indexOf(d)); true }
        }
        updatingTabs = false
        if (docs.isEmpty()) {
            showDoc(-1)
        } else if (wasCurrent) {
            showDoc(tabs.selectedTabPosition.coerceIn(0, docs.size - 1))
        } else {
            current = tabs.selectedTabPosition
        }
    }

    private fun queryName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) return n.removeSuffix(".pdf").removeSuffix(".PDF")
                }
            }
        } catch (e: Exception) {}
        return uri.lastPathSegment ?: "PDF"
    }

    // ---------------------------------------------------------------- التكبير

    private fun applyZoom(scale: Float) {
        // نرسم الصفحات بدقة أعلى عند التكبير (بخطوات نصف مرة) حتى يبقى النص واضحًا
        val z = (ceil(scale * 2f) / 2f).coerceIn(1f, 2.5f)
        adapter?.setRenderWidth((baseWidth() * z).toInt())
    }

    // ---------------------------------------------------------------- البحث

    private fun openSearch() {
        val doc = currentDoc ?: return
        searchBar.visibility = View.VISIBLE
        backCallback.isEnabled = true
        searchInput.setText(doc.query)
        searchInput.setSelection(searchInput.text.length)
        updateCount(doc)
        searchInput.requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideSearchBar() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(searchInput.windowToken, 0)
        searchBar.visibility = View.GONE
        backCallback.isEnabled = false
    }

    private fun closeSearch() {
        hideSearchBar()
        for (d in docs) {
            d.query = ""
            d.setHits(emptyList())
            d.hitIndex = -1
        }
        adapter?.notifyDataSetChanged()
    }

    private fun submitSearch() {
        val doc = currentDoc ?: return
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(searchInput.windowToken, 0)
        val q = searchInput.text.toString().trim()
        if (q.isEmpty()) {
            clearHits(doc)
            return
        }
        // نفس الكلمة مرة أخرى = الانتقال للنتيجة التالية
        if (q == doc.query && doc.hits.isNotEmpty()) {
            stepHit(1)
            return
        }
        runSearch(doc, q)
    }

    private fun runSearch(doc: PdfDoc, q: String) {
        if (doc.indexFailed) {
            searchCount.setText(R.string.index_failed)
            return
        }
        val index = doc.textIndex
        if (index != null) {
            startSearch(doc, q, index)
            return
        }
        if (doc.indexing) return
        doc.indexing = true
        searchCount.setText(R.string.indexing)
        val appContext = applicationContext
        indexExecutor.execute {
            val result = try {
                TextIndexer.build(appContext, doc.uri) { done, total ->
                    runOnUiThread {
                        if (currentDoc === doc) {
                            searchCount.text = getString(R.string.indexing_progress, done, total)
                        }
                    }
                }
            } catch (e: Throwable) {
                null
            }
            runOnUiThread {
                doc.indexing = false
                doc.textIndex = result
                doc.indexFailed = result == null
                if (!isFinishing && !isDestroyed && docs.contains(doc) &&
                    currentDoc === doc && searchBar.visibility == View.VISIBLE
                ) {
                    if (result == null) {
                        searchCount.setText(R.string.index_failed)
                    } else {
                        val text = searchInput.text.toString().trim()
                        if (text.isNotEmpty()) startSearch(doc, text, result)
                    }
                }
            }
        }
    }

    private fun startSearch(doc: PdfDoc, q: String, index: List<PageText>) {
        if (index.none { it.text.isNotEmpty() }) {
            searchCount.setText(R.string.no_text)
            return
        }
        val firstVisible = if (currentDoc === doc) {
            layoutManager.findFirstVisibleItemPosition().coerceAtLeast(0)
        } else 0
        indexExecutor.execute {
            val hits = Searcher.search(index, q)
            runOnUiThread {
                if (isFinishing || isDestroyed || !docs.contains(doc)) return@runOnUiThread
                doc.query = q
                doc.setHits(hits)
                doc.hitIndex = if (hits.isEmpty()) -1 else {
                    hits.indexOfFirst { it.page >= firstVisible }.let { if (it < 0) 0 else it }
                }
                refreshSearch(doc, scroll = true)
            }
        }
    }

    private fun clearHits(doc: PdfDoc) {
        doc.query = ""
        doc.setHits(emptyList())
        doc.hitIndex = -1
        refreshSearch(doc, scroll = false)
    }

    private fun stepHit(delta: Int) {
        val doc = currentDoc ?: return
        val n = doc.hits.size
        if (n == 0) {
            val q = searchInput.text.toString().trim()
            if (q.isNotEmpty()) runSearch(doc, q)
            return
        }
        doc.hitIndex = ((doc.hitIndex + delta) % n + n) % n
        refreshSearch(doc, scroll = true)
    }

    private fun refreshSearch(doc: PdfDoc, scroll: Boolean) {
        if (currentDoc !== doc) return
        adapter?.notifyDataSetChanged()
        updateCount(doc)
        if (scroll && doc.hitIndex >= 0) scrollToHit(doc)
    }

    private fun updateCount(doc: PdfDoc) {
        searchCount.text = when {
            doc.indexing -> getString(R.string.indexing)
            doc.query.isEmpty() -> ""
            doc.hits.isEmpty() -> getString(R.string.no_results)
            else -> "${doc.hitIndex + 1} / ${doc.hits.size}"
        }
    }

    private fun scrollToHit(doc: PdfDoc) {
        val hit = doc.hits.getOrNull(doc.hitIndex) ?: return
        val top = hit.rects.firstOrNull()?.top ?: 0f
        val pageHeight = layoutManager.findViewByPosition(hit.page)?.height
            ?: (baseWidth() * doc.aspect).toInt()
        // نضع النتيجة في الثلث العلوي من الجزء الظاهر على الشاشة
        val offset = (recycler.viewportTop() + recycler.viewportHeight() / 3f - top * pageHeight).toInt()
        layoutManager.scrollToPositionWithOffset(hit.page, offset)
        recycler.post { updateIndicator() }
    }

    // ---------------------------------------------------------------- حفظ الجلسة

    override fun onStop() {
        super.onStop()
        saveScroll()
        getSharedPreferences("session", MODE_PRIVATE).edit()
            .putString("uris", docs.joinToString("\n") { it.uri.toString() })
            .putInt("current", current)
            .apply()
    }

    private fun restoreSession() {
        val prefs = getSharedPreferences("session", MODE_PRIVATE)
        val saved = prefs.getString("uris", "").orEmpty().lines().filter { it.isNotBlank() }
        for (s in saved) openUri(Uri.parse(s))
        if (docs.isNotEmpty()) selectTab(prefs.getInt("current", 0).coerceIn(0, docs.size - 1))
    }

    override fun onDestroy() {
        super.onDestroy()
        adapter?.dispose()
        renderExecutor.shutdownNow()
        indexExecutor.shutdownNow()
        docs.forEach { it.close() }
        docs.clear()
    }
}
