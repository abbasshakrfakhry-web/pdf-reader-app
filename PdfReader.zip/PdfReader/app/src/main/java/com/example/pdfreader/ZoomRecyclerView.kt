package com.example.pdfreader

import android.content.Context
import android.graphics.Canvas
import android.graphics.Matrix
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.recyclerview.widget.RecyclerView

/**
 * RecyclerView يدعم التكبير بالإصبعين، والسحب الأفقي عند التكبير،
 * والنقر المزدوج للتكبير/الرجوع. التمرير العمودي يبقى من RecyclerView نفسه.
 */
class ZoomRecyclerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : RecyclerView(context, attrs) {

    var scaleFactor = 1f
        private set
    private var tx = 0f
    private var ty = 0f

    /** يُستدعى بعد انتهاء التكبير (لإعادة رسم الصفحات بدقة أعلى). */
    var onZoomSettled: ((Float) -> Unit)? = null

    private var ignoring = false
    private var lastX = 0f
    private val tmpMatrix = Matrix()

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                zoomTo(scaleFactor * detector.scaleFactor, detector.focusX, detector.focusY)
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                onZoomSettled?.invoke(scaleFactor)
            }
        }
    )

    private val tapDetector = GestureDetector(
        context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (scaleFactor > 1.05f) zoomTo(1f, e.x, e.y) else zoomTo(2.5f, e.x, e.y)
                onZoomSettled?.invoke(scaleFactor)
                return true
            }
        }
    )

    fun zoomTo(target: Float, focusX: Float, focusY: Float) {
        val newScale = target.coerceIn(1f, MAX_SCALE)
        val px = (focusX - tx) / scaleFactor
        val py = (focusY - ty) / scaleFactor
        scaleFactor = newScale
        tx = focusX - px * newScale
        ty = focusY - py * newScale
        clampTranslation()
        invalidate()
    }

    fun resetZoom() {
        scaleFactor = 1f
        tx = 0f
        ty = 0f
        invalidate()
    }

    /** أعلى نقطة ظاهرة على الشاشة بإحداثيات RecyclerView. */
    fun viewportTop(): Float = -ty / scaleFactor

    /** ارتفاع المنطقة الظاهرة بإحداثيات RecyclerView. */
    fun viewportHeight(): Float = height / scaleFactor

    private fun clampTranslation() {
        tx = tx.coerceIn(width * (1f - scaleFactor), 0f)
        ty = ty.coerceIn(height * (1f - scaleFactor), 0f)
    }

    private fun obtainTransformed(ev: MotionEvent): MotionEvent {
        val e = MotionEvent.obtain(ev)
        tmpMatrix.reset()
        tmpMatrix.postTranslate(-tx, -ty)
        tmpMatrix.postScale(1f / scaleFactor, 1f / scaleFactor)
        e.transform(tmpMatrix)
        return e
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(ev)
        tapDetector.onTouchEvent(ev)

        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            ignoring = false
            lastX = ev.x
        }

        // أثناء القرصة: ألغِ اللمسة عن RecyclerView وتجاهل الباقي حتى لمسة جديدة
        if (ev.pointerCount > 1 || scaleDetector.isInProgress) {
            if (!ignoring) {
                ignoring = true
                val cancel = obtainTransformed(ev)
                cancel.action = MotionEvent.ACTION_CANCEL
                super.dispatchTouchEvent(cancel)
                cancel.recycle()
            }
            return true
        }
        if (ignoring) return true

        if (ev.actionMasked == MotionEvent.ACTION_MOVE) {
            if (scaleFactor > 1f) {
                tx += ev.x - lastX
                clampTranslation()
                invalidate()
            }
            lastX = ev.x
        }

        val transformed = obtainTransformed(ev)
        val handled = super.dispatchTouchEvent(transformed)
        transformed.recycle()
        return handled
    }

    override fun dispatchDraw(canvas: Canvas) {
        canvas.save()
        canvas.translate(tx, ty)
        canvas.scale(scaleFactor, scaleFactor)
        super.dispatchDraw(canvas)
        canvas.restore()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        clampTranslation()
    }

    companion object {
        const val MAX_SCALE = 5f
    }
}
