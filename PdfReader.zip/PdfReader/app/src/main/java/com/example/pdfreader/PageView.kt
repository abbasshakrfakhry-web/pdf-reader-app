package com.example.pdfreader

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.widget.ImageView

/** صفحة PDF واحدة، ترسم فوق الصورة تظليل نتائج البحث. */
class PageView(context: Context) : ImageView(context) {

    /** قائمة (رقم النتيجة، المستطيلات بنسب 0..1 من حجم الصفحة). */
    var highlights: List<Pair<Int, List<RectF>>> = emptyList()
    var currentHit: Int = -1

    private val normalPaint = Paint().apply { color = 0x66FFEB3B }
    private val currentPaint = Paint().apply { color = 0x99FF9800.toInt() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (highlights.isEmpty()) return
        val w = width.toFloat()
        val h = height.toFloat()
        for ((index, rects) in highlights) {
            val paint = if (index == currentHit) currentPaint else normalPaint
            for (r in rects) {
                canvas.drawRect(r.left * w, r.top * h, r.right * w, r.bottom * h, paint)
            }
        }
    }
}
