package com.example.pdfreader

import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.ExecutorService
import kotlin.math.abs

class PageAdapter(
    private val doc: PdfDoc,
    private val baseWidth: Int,
    private val executor: ExecutorService
) : RecyclerView.Adapter<PageAdapter.VH>() {

    private val handler = Handler(Looper.getMainLooper())
    private var disposed = false

    /** العرض (بالبكسل) الذي تُرسم به الصور؛ يزيد عند التكبير لوضوح أعلى. */
    private var renderWidth = baseWidth

    class VH(val view: PageView) : RecyclerView.ViewHolder(view)

    fun dispose() {
        disposed = true
    }

    fun setRenderWidth(width: Int) {
        if (abs(width - renderWidth) > 8) {
            renderWidth = width
            notifyDataSetChanged()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = PageView(parent.context).apply {
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            setBackgroundColor(Color.WHITE)
        }
        return VH(v)
    }

    override fun getItemCount() = doc.pageCount

    override fun onBindViewHolder(holder: VH, position: Int) {
        val v = holder.view
        v.tag = position
        v.highlights = doc.hitsByPage[position] ?: emptyList()
        v.currentHit = doc.hitIndex

        val cached = doc.cached(position)
        if (cached != null) {
            setBitmap(holder, cached)
            if (cached.requestedWidth < renderWidth - 8) enqueue(holder, position)
            return
        }
        v.setImageBitmap(null)
        v.layoutParams = RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            (baseWidth * doc.aspect).toInt()
        )
        enqueue(holder, position)
    }

    private fun enqueue(holder: VH, position: Int) {
        val width = renderWidth
        executor.execute {
            if (disposed || (holder.view.tag as? Int) != position) return@execute
            val result = try { doc.render(position, width) } catch (e: Throwable) { null }
                ?: return@execute
            handler.post {
                if (!disposed && (holder.view.tag as? Int) == position) setBitmap(holder, result)
            }
        }
    }

    private fun setBitmap(holder: VH, rendered: Rendered) {
        val v = holder.view
        v.layoutParams = RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        v.setImageBitmap(rendered.bitmap)
    }
}
